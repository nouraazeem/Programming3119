"""
(2) Write a python function to find the longest words in a text file. I will be using mbox.txt from class

"""



def lookforlongword(filename):
	
	with open(filename, 'r') as infile:

		words = infile.read().split()
		max_len = len(max(words, key=len))

	return [word for word in words if len(word) == max_len]

print(lookforlongword('mbox.txt'))













