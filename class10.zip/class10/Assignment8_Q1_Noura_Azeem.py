"""
(1) Write a Python function to count the number of lines in a text file. I used the mbox.txt file that we were given in class to read how many lines were in the file. 

"""


def lengthoffile(fname):
	with open(fname) as f:
		for i, l in enumerate(f):
			pass
		return i + 1
print("There are this number of lines in the file ",lengthoffile("mbox.txt"))




































